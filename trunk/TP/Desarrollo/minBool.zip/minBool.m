function result = minBool(numbers, resulttype)
% MINBOOL Quine-McCluskey method for boolean function minimization
%
% R = minBool( N, V )
%
% R - result matrix
% N - input arguments. N should be vector with integers
% V - visualization type
%     1) 1=normal; -1=inverse; NaN = not used
%     2) 1=normal; -1=inverse; 0   = not used
%
% Example
% R = minBool([5 13 14 26 30],1)
% R =
%    1     2     3     4     5
%   -1   NaN     1    -1     1
%  NaN     1     1     1    -1
%    1     1   NaN     1    -1
%
% This function is distributed under GPL license (see code for details).
% Original authors information:    Andrey Popov       www.automatics.hit.bg
%
% minBool ver. 1.3,     release Sept 2002,         Last update: 14 Feb 2010

% Copyright 2002-2010        Andrey Popov          andrey.popov@gmx.net
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.




%% Input arguments check
if (nargin==0)
    error('minBool:noinput','No input data');
end

% The input argument is integer numbers, so the minimization is
% independant on the size of the boolean variables, i.e. we are not
% interested whether the real boolean variables are represented with 3 or
% 30 bits

numbers = round(abs(numbers));
v = size(numbers,2);
numbers = numbers(:);

%% Remove repeated input numbers ------------------------------------------
S = numbers(1);
for g = 2:v
    if ~any(S == numbers(g))
        S = [S numbers(g)];
    end
end

numbers = sort(S);
v = length(numbers);

% Determine the number of involved boolean variables
n = max(1,ceil(log2(max(numbers)+1)));

% Create empty disjunction matrix s
W = zeros(v,n);

%% Convert the input numbers to binary ------------------------------------
for i = 1:v % cycle over the numbers
    k = numbers(i);
    for j = 1:n % cycle over the bits
        p = 2^(n-j);
        if  k >= p
            k = k - p;
            W(i,j) = 1;
        end
    end
end

%% Arange the numbers according to the number of '1' they have ------------
w1 = [1:v; sum(W,2)'];   % [no; num 1's]
w1 = sortrows(w1',2);    % sort by num 1's
w = w1(:,1);
G = [W(w,:) numbers(w)'];% arrange by num 1's

%% Joining the numbers close in a boolean sence ---------------------------
extend=1;		%
stitched=1;		% to be able to enter 'while'

if v == 1
    F = G;
else
    while (stitched~=0)
        F = [];
        stitched = 0;

        G = [G zeros(v,1)];
        ncomb = 0;

        for i=1:v                   % loop over all combinations
            if ~isinf(G(i,1))
                % Inf on first position can appear only if we have 2
                % combinations which are identical. Since this is covered
                % for the initial input variables, such case can only
                % occure after combining several variables and having
                % invariant bits.
                joined=0;
                
                for j=(i+1):v		% compare with all other combinations
                    if ~isinf(G(j,1)) % allowed
                        k = sum(abs(G(i,1:n)-G(j,1:n)));
                        if k == 1   % difference by exactely 1 bit
                            L = G(i,1:(n+extend));	% copy the combination
                            p = find(G(i,1:n)-G(j,1:n)); % find the differing bit
                            L(1,p) = -1;			% mark it with -1
                            L = [L G(j,(n+1):(n+extend))]; % add the other combination
                            F = [F; L];             % store in the pass matrix F
                            ncomb = ncomb + 1;
                            stitched = stitched + 1;% mark that there was stitch
                            joined = joined + 1; %
                            G(i,n+extend+1) = 1; % mark the combinations as used
                            G(j,n+extend+1) = 1;
                        elseif k == 0 % could be only by 2 identical combinations
                                      % at later stage of stitching
                            G(j,1)=inf;
                        end
                    end
                end

                if joined == 0 && G(i,n+extend+1) == 0
                    % the current combination cannot be joined with any
                    % other
                    L = G(i,1:(n+extend));
                    L = [L Inf*ones(1,extend)];
                    F = [F; L];
                    ncomb = ncomb + 1;	% however this is a combination
                end
            end
        end % end of the cycle over the combinations

        if stitched == 0	% not a single combination pare found
            F = F(:,1:(n+extend));	% this removes the extra combination columns
        else
            extend = 2*extend; % the number of spaces to mark combinations is doubled
        end

        G = F; % not the combinations are written again in G

        v = ncomb;
    end
end % end of the while cycle


%% Create the table -------------------------------------------------------
%  extend - max number of the involved input variables in the output
%  n - number of boolean variables
%  v - number of derived combinations
%  y - number input combinations
y = length(numbers);

E = zeros(v+2,y+3);			% create empty table of the form
%  0 0 0 i i i i i i i   		i � input combinations
%  0 0 0 t t t t t t t 			t � is this variable included
%  x n u ; ; ; ; ; ; ;			x � output combination
%  x n u ; ; ; ; ; ; ;			n � number of the included base variables
%  x n u ; ; ; ; ; ; ;			u � is this output combination used
%  x n u ; ; ; ; ; ; ;			; - 1/0 depending on whether the output combination uses the corresponding input combination

E(1,3+(1:y)) = numbers;
E(2+(1:v),1) = [1:v]';
   
% Fill with 1/0 depending on the variables involved
for g = 1:v
    for j = n+(1:extend)
        if ~isnan(F(g,j))
            for i = 1:y
                if E(1,i+3) == F(g,j)
                    E(g+2,i+3) = 1;
                end
            end
        end
    end
end


%% Mark the base input variables (those involved in only 1 output)---------
marked=0;
for j = 3+(1:y)
    if E(2,j) ~= 1	% the input variable is not yet involved in an output one
        if sum(E(2+(1:v),j)==1) == 1		% this is a base variable
            E(2,j) = 1;
            marked = marked + 1;
            p = find(E(2+(1:v),j)==1);
            E(2+p,3) = 1;				% mark the output variable as used
            for h = 1:y
                if E(2+p,h+3) == 1		% this output var. includes also other input
                    if E(2,h+3) == 0 	% not yet marked input
                        E(2,h+3) = 1;
                        marked = marked + 1;
                    end
                end
            end
        end
    end
end


%% Mark the non-base variables --------------------------------------------
while marked < y
    E(2+(1:v),2) = zeros(v,1);

    for g=1:v
        if E(g+2,3)==0
            p=0;				% num included, but non-marked non-base variables
            for j=3+(1:y)
                if E(g+2,j)==1 && E(2,j)==0	% output combination, containing the 
                    % non-marked, non-base boolean combination
                    p=p+1;
                end
            end
            
            % Calculate extra weighing coef. based on the
            % number of boolean combination describing the particular
            % combination (q) and number of inverted (negated) boolean
            % variables (c)
            q = sum(F(g,1:n)<0);
            c = sum(F(g,1:n)==0);

            E(g+2,2) = p + q/(n+1) + c/(10*n);	
            % Thus the choice of this combination is done depending upon
            % 1) how many of the input numbers it describes
            % 2) with how mnay boolean variables it is described
            % 3) how many of the boolean variables are inverted
        end
    end

    maks = max(E(:,2));

    g=1;
    while E(g+2,2)<maks
        g=g+1;
    end

    E(g+2,3) = 1;
    for h = 1:y
        if E(g+2,h+3) == 1
            if E(2,h+3) == 0; 	% this was unmarked value
                E(2,h+3) = 1;
                marked = marked + 1;
            end
        end
    end
end


%% Generate the output variables ------------------------------------------
Z=[];		% matrix for the output variables

output = 0;
for g = 1:v
    if E(g+2,3) == 1
        Z = [Z; F(g,:)];
        output = output + 1;
    end
end
Z = Z(:,1:n);

%% Forming the result =====================================================
if nargin == 1
    resulttype = 2;
end

% Define how the result is stored
% T : x    F : inv(x)   N : -
if resulttype == 2
    T = 1; F = -1; N = 0; 
else
    T = 1; F = -1; N = NaN;
end 

B = Z;
B(Z==-1) = N;
B(Z==1)  = T;
B(Z==0)  = F;

result = [1:n; B];
